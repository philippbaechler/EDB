#ifndef SOURCES_EDB_PLATFORM_H_
#define SOURCES_EDB_PLATFORM_H_

#include <stdint.h>
#include <stdbool.h>
#include "PE_Types.h"

#define PL_CONFIG_HAS_LEDS		(1)
#define PL_CONFIG_HAS_EVENTS	(1)
#define PL_CONFIG_HAS_TIMER		(1)
#define PL_CONFIG_HAS_KEYS		(1)
#define PL_CONFIG_HAS_RTOS		(1)

#define PL_CONFIG_NOF_LEDS		(3)
#define PL_CONFIG_NOF_KEYS		(3)
#define PL_CONFIG_KEY_1_ISR		(1)
#define PL_CONFIG_KEY_2_ISR		(1)
#define PL_CONFIG_KEY_3_ISR		(1)

void PL_Init(void);
void PL_Deinit(void);

#endif /* SOURCES_EDB_PLATFORM_H_ */
