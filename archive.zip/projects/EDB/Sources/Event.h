#ifndef EVENT_H_
#define EVENT_H_

#include "Platform.h"

#if PL_CONFIG_HAS_EVENTS

typedef enum EVNT_Handle{
	EVNT_STARTUP,

#if PL_CONFIG_HAS_KEYS
	#if PL_CONFIG_NOF_KEYS >= 1
	EVNT_SW1_PRESSED,
	#endif
	#if PL_CONFIG_NOF_KEYS >= 2
	EVNT_SW2_PRESSED,
	#endif
	#if PL_CONFIG_NOF_KEYS >= 3
	EVNT_SW3_PRESSED,
	#endif
#endif

	EVNT_NOF_EVENTS
} EVNT_Handle;

void EVNT_SetEvent(EVNT_Handle event);

void EVNT_ClearEvent(EVNT_Handle event);

bool EVNT_EventIsSet(EVNT_Handle event);

bool EVNT_EventIsSetAutoClear(EVNT_Handle event);

void EVNT_HandleEvent(void (*callback)(EVNT_Handle), bool clearEvent);

void EVNT_Init(void);

void EVNT_Deinit(void);

#endif /* PL_HAS_EVENTS */

#endif /* EVENT_H_ */
