#include "Platform.h"
#include "Application.h"
#include "Event.h"
#include "LED.h"
#include "Wait1.h"
#include "CS1.h"
#include "Keys.h"
//#include "CLS1.h"
#include "Motors.h"

#if PL_CONFIG_HAS_EVENTS

static void APP_EventHandler(EVNT_Handle event){
	switch(event){
	case EVNT_STARTUP:
		LED1_On();
		WAIT1_Waitms(50);
		LED1_Off();
		WAIT1_Waitms(50);
		LED2_On();
		WAIT1_Waitms(50);
		LED2_Off();
		WAIT1_Waitms(50);
		LED3_On();
		WAIT1_Waitms(50);
		LED3_Off();
		break;

#if PL_CONFIG_HAS_KEYS
	#if PL_CONFIG_NOF_KEYS >= 1
	case EVNT_SW1_PRESSED:
		//CLS1_SendStr("SW1 pressed\r\n", CLS1_GetStdio()->stdOut);
		break;
	#endif
	#if PL_CONFIG_NOF_KEYS >= 2
	case EVNT_SW2_PRESSED:
		//CLS1_SendStr("SW2 pressed\r\n", CLS1_GetStdio()->stdOut);
		break;
	#endif
	#if PL_CONFIG_NOF_KEYS >= 3
	case EVNT_SW3_PRESSED:
		//CLS1_SendStr("SW3 pressed\r\n", CLS1_GetStdio()->stdOut);
		break;
	#endif
#endif /* PL_CONFIG_HAS_KEYS */
	} /* switch-case*/
} /* APP_EventHandler */

#endif /* PL_CONFIG_HAS_EVENTS */

void APP_Start(void){
	PL_Init();
	int i;

#if PL_CONFIG_HAS_EVENTS
	EVNT_SetEvent(EVNT_STARTUP);
#endif

	for(;;){
#if PL_CONFIG_HAS_KEYS
		KEY_Scan();
#endif
#if PL_CONFIG_HAS_EVENTS
		EVNT_HandleEvent(APP_EventHandler, TRUE);
#endif
		/*for(i = 0; i < 65; i++){
			PPG1_SetRatio16(i * 1000);
			WAIT1_Waitms(500);
		}
		WAIT1_Waitms(1000);
		//CLS1_SendStr("Hello World\r\n", CLS1_GetStdio()->stdOut);
		PPG1_SetDutyMS(10);
		for(i = 0; i < 65; i++){
			PPG1_SetRatio16(i * 1000);
			WAIT1_Waitms(500);
		}
		WAIT1_Waitms(1000);
		PPG1_SetDutyMS(20);
		for(i = 0; i < 65; i++){
			PPG1_SetRatio16(i * 1000);
			WAIT1_Waitms(500);
		}
		WAIT1_Waitms(1000);
		PPG1_SetDutyMS(30);
		for(i = 0; i < 65; i++){
			PPG1_SetRatio16(i * 1000);
			WAIT1_Waitms(500);
		}
		WAIT1_Waitms(1000);
		PPG1_SetDutyMS(40);
		for(i = 0; i < 65; i++){
			PPG1_SetRatio16(i * 1000);
			WAIT1_Waitms(500);
		}

		WAIT1_Waitms(1000);*/

		/*
		PPG1_SetRatio16(50000);

		for(i = 0; i < 40; i++)
		{
			PPG1_SetDutyMS(i);
			WAIT1_Waitms(500);
		}*/

		/*for(i = 0; i < 65; i++){
			TPM0_C0V = (i * 1000);
			WAIT1_Waitms(500);
		}*/

		MOT_Init();

		MOT_CalcValues(&motorLeft, 10, 10, 1000);

		MOT_MoveSteps(&motorLeft, 1000);

		MOT_Process(&motorLeft);

		while(TRUE);

	}


}
