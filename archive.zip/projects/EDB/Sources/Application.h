#ifndef SOURCES_APPLICATION_H_
#define SOURCES_APPLICATION_H_

void APP_Start(void);

#endif /* SOURCES_APPLICATION_H_ */
