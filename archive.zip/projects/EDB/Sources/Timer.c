#include "Platform.h"
#if PL_CONFIG_HAS_TIMER
#include "Timer.h"
#include "Event.h"

void TMR_OnInterrupt(void) {
  /* this one gets called from an interrupt!!!! */

  /* this one gets called from an interrupt!!!! */
}

void TMR_Init(void) {
}

void TMR_Deinit(void) {
}

#endif /* PL_CONFIG_HAS_TIMER*/
