#ifndef KEYS_H_
#define KEYS_H_

#include "Platform.h"

#if PL_CONFIG_HAS_KEYS

typedef enum{
#if PL_CONFIG_NOF_KEYS >= 1
	KEY_BTN1,
#endif
#if PL_CONFIG_NOF_KEYS >= 2
	KEY_BTN2,
#endif
#if PL_CONFIG_NOF_KEYS >= 3
	KEY_BTN3,
#endif
	KEY_BTN_LAST
} KEY_Buttons;

#if PL_CONFIG_NOF_KEYS >= 1
	#include "SW1.h"

	#define KEY1_Get()	(!(SW1_GetVal())) /* Macro which returns TRUE if key is pressed */
#else
	#define KEY1_Get()	FALSE /* if we don not have a button, then return 'not pressed' */
#endif

#if PL_CONFIG_NOF_KEYS >= 2
	#include "SW2.h"

	#define KEY2_Get()	(!(SW2_GetVal()))) /* Macro which returns TRUE if key is pressed */
#else
	#define KEY2_Get()	FALSE /* if we don not have a button, then return 'not pressed' */
#endif

#if PL_CONFIG_NOF_KEYS >= 3
	#include "SW3.h"

	#define KEY3_Get()	(!(SW3_GetVal())) /* Macro which returns TRUE if key is pressed */
#else
	#define KEY3_Get()	FALSE /* if we don not have a button, then return 'not pressed' */
#endif

#if PL_CONFIG_HAS_KBI /* keyboard interrupt */

void KEY_OnInterrupt(KEY_Buttons button);

void KEY_EnableInterrupts(void);

void KEY_DisableInterrupts(void);

#endif /* PL_CONFIG_HAS_KBI */

void KEY_Scan(void);

void KEY_Init(void);

void KEY_Deinit(void);

#endif /* PL_CONFIG_HAS_KEYS */

#endif /* KEYS_H_ */
