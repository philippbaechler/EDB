/* ###################################################################
**     Filename    : main.c
**     Project     : EDB
**     Processor   : MKL25Z128VLK4
**     Version     : Driver 01.01
**     Compiler    : GNU C Compiler
**     Date/Time   : 2016-03-09, 09:50, # CodeGen: 0
**     Abstract    :
**         Main module.
**         This module contains user's application code.
**     Settings    :
**     Contents    :
**         No public methods
**
** ###################################################################*/
/*!
** @file main.c
** @version 01.01
** @brief
**         Main module.
**         This module contains user's application code.
*/         
/*!
**  @addtogroup main_module main module documentation
**  @{
*/         
/* MODULE main */


/* Including needed modules to compile this module/procedure */
#include "Cpu.h"
#include "Events.h"
#include "FRTOS.h"
#include "UTIL1.h"
#include "LEDpin1.h"
#include "BitIoLdd4.h"
#include "LEDpin2.h"
#include "BitIoLdd5.h"
#include "LEDpin3.h"
#include "BitIoLdd6.h"
#include "SIG.h"
#include "ILIM.h"
#include "M1_STEP.h"
#include "BitIoLdd1.h"
#include "M1_DIR.h"
#include "BitIoLdd2.h"
#include "M1_nRST.h"
#include "BitIoLdd3.h"
#include "M1_MODE0.h"
#include "BitIoLdd7.h"
#include "M1_MODE1.h"
#include "BitIoLdd8.h"
#include "M1_MODE2.h"
#include "BitIoLdd9.h"
#include "M1_FAULT.h"
#include "BitIoLdd10.h"
#include "M1_LIM.h"
#include "BitIoLdd11.h"
#include "M2_STEP.h"
#include "BitIoLdd12.h"
#include "M2_DIR.h"
#include "BitIoLdd13.h"
#include "M2_nRST.h"
#include "BitIoLdd14.h"
#include "M2_MODE0.h"
#include "BitIoLdd15.h"
#include "M2_MODE1.h"
#include "BitIoLdd16.h"
#include "M2_MODE2.h"
#include "BitIoLdd17.h"
#include "M2_FAULT.h"
#include "BitIoLdd18.h"
#include "M2_LIM.h"
#include "BitIoLdd19.h"
#include "WAIT1.h"
#include "SW1.h"
#include "ExtIntLdd1.h"
#include "SW2.h"
#include "ExtIntLdd2.h"
#include "SW3.h"
#include "ExtIntLdd3.h"
#include "CS1.h"
/* Including shared modules, which are used for whole project */
#include "PE_Types.h"
#include "PE_Error.h"
#include "PE_Const.h"
#include "IO_Map.h"
/* User includes (#include below this line is not maintained by Processor Expert) */

#include "Application.h"

/*lint -save  -e970 Disable MISRA rule (6.3) checking. */
int main(void)
/*lint -restore Enable MISRA rule (6.3) checking. */
{
  /* Write your local variable definition here */

  /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
  PE_low_level_init();
  /*** End of Processor Expert internal initialization.                    ***/

  /* Write your code here */
  /* For example: for(;;) { } */

  LDD_TDeviceData* TU1;

  APP_Start();

  /*** Don't write any code pass this line, or it will be deleted during code generation. ***/
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;){}
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

/* END main */
/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.5 [05.21]
**     for the Freescale Kinetis series of microcontrollers.
**
** ###################################################################
*/
