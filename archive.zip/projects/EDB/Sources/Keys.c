#include "Platform.h"
#if PL_CONFIG_HAS_KEYS
	#include "Keys.h"
#if PL_CONFIG_HAS_EVENTS
	#include "Event.h"
#endif /* PL_CONFIG_HAS_EVENTS */

void KEY_Scan(void) {
	#if PL_CONFIG_NOF_KEYS >= 1 && !PL_CONFIG_KEY_1_ISR
		if (KEY1_Get()){ /* key pressed */
			EVNT_SetEvent(EVNT_SW1_Pressed);
		}
	#endif
	#if PL_CONFIG_NOF_KEYS >= 2 && !PL_CONFIG_KEY_2_ISR
		if (KEY2_Get()){ /* key pressed */
			EVNT_SetEvent(EVNT_SW2_Pressed);
		}
	#endif
	#if PL_CONFIG_NOF_KEYS >= 3 && !PL_CONFIG_KEY_3_ISR
		if (KEY3_Get()){ /* key pressed */
			EVNT_SetEvent(EVNT_SW3_Pressed);
		}
	#endif
}

void KEY_Init(void){

}

void KEY_Deinit(void){

}
#endif /* PL_CONFIG_HAS_KEYS */
